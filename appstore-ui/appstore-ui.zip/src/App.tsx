import React, { useEffect, useState } from "react";

interface AppData {
  name: string;
  developer: string;
  current_rank: number;
}

function App() {
  const [apps, setApps] = useState<AppData[]>([]);

  useEffect(() => {
    fetch("http://127.0.0.1:8000/top50?country=US&category=OVERALL")
      .then((res) => res.json())
      .then((data) => setApps(data.apps.slice(0, 10))); // Top 10
  }, []);

  return (
    <div className="p-6">
      <h1 className="text-2xl font-bold mb-4">📱 Top 50 Free Apps (US)</h1>
      <ul className="space-y-2">
        {apps.map((app, idx) => (
          <li
            key={idx}
            className="border rounded-lg p-3 bg-white shadow-sm flex justify-between"
          >
            <span>{idx + 1}. {app.name}</span>
            <span className="text-gray-500">{app.developer}</span>
          </li>
        ))}
      </ul>
    </div>
  );
}

export default App;
